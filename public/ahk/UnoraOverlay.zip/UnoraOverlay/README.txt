UNORA OVERLAY  -  the Unora Wiki, right on top of your game
=============================================================

Unora Overlay opens the Unora Wiki (unora.wiki) in a small window that sits
over the game, so you can check a quest guide, look up an item, compare gear
or plan your skills without alt-tabbing to a browser.

It shows the real website, so it is always up to date with the wiki.


WHAT YOU NEED
-------------
1. Windows 10 or Windows 11.
2. Microsoft Edge WebView2 Runtime. It is already on Windows 11 and on up-to-date
   Windows 10. If the overlay says the browser could not start, install it free from:
   https://developer.microsoft.com/microsoft-edge/webview2/


INSTALL
-------
1. Unzip the whole UnoraOverlay folder somewhere you can write files, such as
   Documents or Desktop. (Avoid "Program Files".)
2. Keep everything together. The folder must contain:
      UnoraOverlay.exe   (start this one - it is the AutoHotkey engine, already included)
      UnoraOverlay.ahk   (the overlay itself)
      UnoraOverlay.ico   (the icon)
      README.txt
      Lib\            (the browser helper files - do not delete)
3. Double-click UnoraOverlay.exe. The first time, the menu opens by itself.
   Nothing else needs to be installed. (If you already have AutoHotkey v2, double-clicking
   UnoraOverlay.ahk works too.)

The overlay lives in your system tray (bottom-right, near the clock). Right-click
its icon for the menu, Options, and Exit.


PLAYING WITH THE GAME
---------------------
* Run the game in Windowed or Borderless-windowed mode. A true "exclusive
  fullscreen" game will hide the overlay.
* If your game runs "as administrator", run UnoraOverlay.exe as administrator
  too (right-click the file > Run as administrator), or the keybinds will not
  work while the game is focused.
* The wiki window can be moved and resized like any window. Press Pin to keep
  it on top of the game (or unpin it).


KEYBINDS (the defaults)
-----------------------
  Ctrl+Alt+U    Open the menu
  Ctrl+Alt+W    Show / hide the wiki window
  Ctrl+Alt+B    Open the Build Planner
  Ctrl+Alt+H    Open the HP/MP Calculator
  Ctrl+Alt+S    Open the Stat Calculator
  Ctrl+Alt+O    Open Options
  Ctrl+Alt+Middle click    Add the skill/spell under the mouse to your Build Planner (see below)

Change any of them in Options (see below).


THE MENU
--------
Press the Menu key. The menu has two parts.

Unora Wiki (opens the wiki window):
  Classes        Skills and spells for every class. On a class page, use the
                 "Build Plan" button to plan what to learn, just like the website.
  Items          All equipment. Use "Compare Equipment" to compare items,
                 and pick an enchant to see how it changes the stats.
  Quests         Quest guides.
  Professions    Recipes and tables for each profession.

Tools (each opens its own small window):
  Build Planner      Just your build plan.
  HP/MP Calculator   Experience costs for raising HP and MP.
  Stat Calculator    Experience needed to max your stats.

The ? button explains the page or window you are looking at. It is at the top right of the
menu, the wiki window, and the Build Planner, HP/MP Calculator and Stat Calculator windows.

The wiki window has a bar along the top:
  Back / Forward / Reload   work like a browser
  Menu       opens the menu again
  Planner    opens the Build Planner window
  Pin        keeps the window on top of the game
  Options    opens Options
  ?          help for the page you are looking at
Closing the wiki window with its X only hides it. Your page is still there when
you open it again. To quit completely, right-click the tray icon > Exit.


THE BUILD PLANNER AND "REMEMBERING"
-----------------------------------
The Build Planner button (Ctrl+Alt+B) opens a small, separate window with just your plan.
Press the key again to hide it. It stays on top of the game (the Pin setting) and remembers where you put it.
Click the ? at the top right of the window for a short guide, including the in-game add key.
  - The drop-down at the top switches class. "Your plans" are classes with picks; "Start a plan for..."
    lists the rest.
  - Type a skill or spell name in the box and press Enter (or click a result) to add it.
  - The plan shows where to learn each one, the gold, the highest STR/INT/WIS/CON/DEX needed
    for everything selected, and the materials, which you can tick off. X removes a skill.
  - Picks are shared with the main wiki window, so changes in either show up in both.


Your Build Plan picks, hidden skills, ticked-off materials and other website
settings are remembered between sessions. The overlay keeps its own browser
storage in the "data" folder next to the script.
IMPORTANT: this is separate from your normal web browser. Picks made on
unora.wiki in Chrome/Edge do not appear in the overlay, and the other way round.
Do not delete the "data" folder unless you want to forget your picks.


THE HP/MP CALCULATOR
--------------------
Menu > HP/MP Calculator (or Ctrl+Alt+H) opens a small window with just the calculator.
Press the key again to hide it. It stays on top of the game and remembers where you put it.
HP goes up in steps of 50 and MP in steps of 25. Each raise costs 500 experience for every
point of your base before the raise (for example HP 58,074 to 58,124 costs 29,037,000).
  Between Two Bases   Type a starting and an ending base for HP, MP or both and press Calculate
                      to see the total experience.
  Max Raise from Exp  Choose HP or MP, type your current base and the experience you have, and
                      it shows the base you can reach and what is left over.
Click the ? at the top right of the window for a short guide.


THE STAT CALCULATOR
-------------------
Menu > Stat Calculator (or Ctrl+Alt+S) opens a small window with just the stat calculator.
Press the key again to hide it. It stays on top of the game and remembers where you put it.
  1. Pick your Class and Progression (Pre-Master, Master or Grandmaster). The maximum for each
     stat is filled in.
  2. Type your current STR, INT, WIS, CON and DEX.
  3. Optional: XP/hour (in millions) gives an estimated time, and Current Experience is taken
     off the total.
The result lists the experience needed for each stat and the total.
Click the ? at the top right of the window for a short guide.


OPTIONS
-------
Open it with the Options key, the Options button, or the tray menu.

  Keybinds     Click a box and press the keys you want. Backspace clears one.
               Each action needs its own key. Reset keys restores the defaults.
               "Add skill/spell from game (mouse)" is a mouse click, so it has a list instead
               of a key box (see ADD A SKILL FROM THE GAME below).
  Appearance   Colour theme: Unora (the website's colours - the default), Dark,
               Light, Midnight (dark blues), Crimson (dark reds), Forest (dark greens).
               Fade when not in use: the wiki, Build Planner, HP/MP Calculator and Stat Calculator windows fade to this level
               when your mouse is away from them and you are not using them, so the game
               shows through. They turn fully solid again as soon as you point at them or
               click them, so they stay easy to read. 100 turns fading off.
               If a window ever looks blank or black, set this to 100.
               Page size (zoom): make the website smaller or bigger inside the window.
  Window       Keep the wiki window on top of the game.
  Game         Start automatically when the game launcher opens (see below).
  Updates      Check for a new version when the overlay starts.

Your choices are saved in two small text files next to the script:
  settings.cfg   theme, window size/position, opacity, zoom, update options
  keybinds.cfg   your keys
You can open them in Notepad. Deleting one resets that part to the defaults.
These files are never touched by updates.


ADD A SKILL FROM THE GAME
-------------------------
Point the mouse at a skill or spell in the game (its name or icon on the Skill/Spell page,
or its detail pop-up) and press Ctrl+Alt+Middle click. The overlay takes a small picture of
the screen around the mouse, the Build Planner reads the game's own text from it, finds the
matching skill or spell, and adds it to your plan. A short message near the top of the screen
tells you what was added (or why not). If it is not found in your current class it also
looks through the other classes.
  - It reads only the skill's NAME text, never the icon, so two skills that share a picture are
    never mixed up. If the text could be two similar names, it tells you it is not sure instead of
    guessing; point at the name again or type it in the box.
  - The game must be windowed or borderless. Any window size works, from the game's own 640x480 up
    (1280x960, 1920x1080, a window you dragged to some odd size...). The overlay measures the game
    picture itself. Sizes that are a whole multiple of 640x480 (1280x960, 1920x1440) read most
    reliably. A window smaller than 640x480 is too small to read.
  - Change the click in Options > Keybinds ("Add skill/spell from game (mouse)"). The list has
    Ctrl+Alt, Ctrl+Shift, Alt, Ctrl or Shift + Middle click, the side mouse buttons (Mouse 4 and
    Mouse 5, alone or with Ctrl+Alt or Alt), or Off. Save to apply it.
  - Not reading well? The last picture it looked at is saved in the "data" folder as
    ocr-last.png. You can always type the name into the Build Planner box instead.


START WITH THE GAME LAUNCHER
----------------------------
----------------------------
Tick "Start automatically when the game launcher opens" in Options > Game and Save.
This adds a start-up entry (a shortcut in your Windows Startup folder). From then on the
overlay starts with Windows and waits quietly in the tray (no window, no keybinds). As
soon as the launcher window ("Chaos Launcher") is open, it switches on, shows a small "ready" notice, and
your keybinds work. Untick the box and Save to turn it off again (this removes the
shortcut). To exit the overlay, right-click the tray icon > Exit.
The launcher runs inside "dotnet.exe", so it is found by its window title. If the title is
different, or you want other windows to count too, edit GameWindow in settings.cfg (part of
the title is enough, separate several with commas):  GameWindow=Chaos Launcher,Unora
If you move the UnoraOverlay folder, open the overlay once and press Save in Options
so the start-up entry points to the new place.


UPDATES
-------
When the overlay starts it quietly checks unora.wiki for a newer version. If there
is one, a window tells you what changed and offers:
  Update now          downloads the new UnoraOverlay.ahk, keeps a backup copy
                      (UnoraOverlay.ahk.bak), and restarts the overlay.
  Later               ask again next time.
  Skip this version   stop asking about this version.
Your settings.cfg, keybinds.cfg and saved picks are kept. You can also check any
time from Options > Check now, or the tray menu > Check for updates.
Updates only replace UnoraOverlay.ahk (the engine, UnoraOverlay.exe, stays as it is). If a release ever needs new files in the Lib
folder, the update window will say so and tell you where to download the full package.


TROUBLESHOOTING
---------------
Windows or your antivirus warns about UnoraOverlay.exe:
    UnoraOverlay.exe is the official AutoHotkey v2 program, just renamed so it runs
    UnoraOverlay.ahk automatically. Some antivirus tools are cautious about AutoHotkey
    programs. If yours blocks it, allow the folder, or install AutoHotkey v2 from
    https://www.autohotkey.com and double-click UnoraOverlay.ahk instead.
The overlay does not start / "requires AutoHotkey v2":
    Make sure you start UnoraOverlay.exe from the unzipped folder (not from inside the zip),
    and that UnoraOverlay.ahk is in the same folder.
"The embedded browser could not start":
    Install the WebView2 Runtime (link above), then run the script again.
Keybinds do nothing while in the game:
    Run the overlay as administrator if the game does. Also check the key is not
    already used by the game or another program, and try another in Options.
The window does not show over the game:
    Switch the game to Windowed or Borderless mode.
The window is blank or black:
    Set "Fade when not in use" to 100 in Options. Press Reload in the top bar.
Some other problem with a page:
    Press Reload. If a page is wrong on the website too, tell the wiki team.
"Could not save your settings":
    The folder is read-only. Move the UnoraOverlay folder to Documents.

To uninstall: right-click the tray icon > Exit, then delete the folder.


CREDITS AND LICENCES
--------------------
Unora Wiki is an unofficial fan compendium for Unora: Elemental Harmony.
Browser control: WebView2.ahk by thqby (MIT licence, see Lib\LICENSE-thqby-ahk2_lib.txt),
with Microsoft's WebView2Loader.dll (part of Microsoft Edge WebView2).
UnoraOverlay.exe is the unmodified AutoHotkey v2.0.19 64-bit program (GPLv2,
see Lib\LICENSE-AutoHotkey.txt). Source and downloads: https://www.autohotkey.com
