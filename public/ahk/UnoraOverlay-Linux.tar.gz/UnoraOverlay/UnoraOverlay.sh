#!/bin/sh
# Starts Unora Overlay. Double-click this file (or run it from a terminal).
DIR="$(cd "$(dirname "$0")" && pwd)"

# Window placement, "keep on top" and the keybinds use X11. On a Wayland desktop the
# overlay runs through XWayland (keybinds then only work while an X11/XWayland window,
# such as a Wine game, is focused).
export GDK_BACKEND=x11
# Avoids blank or black pages with some graphics drivers.
: "${WEBKIT_DISABLE_DMABUF_RENDERER:=1}"
export WEBKIT_DISABLE_DMABUF_RENDERER

if ! python3 -c 'import gi; gi.require_version("Gtk","3.0"); from gi.repository import Gtk' 2>/dev/null ||
   ! python3 -c 'import gi
try:
    gi.require_version("WebKit2","4.1")
except ValueError:
    gi.require_version("WebKit2","4.0")
from gi.repository import WebKit2' 2>/dev/null; then
    msg="Unora Overlay needs a few system packages. Run install.sh in the UnoraOverlay folder (see README.txt)."
    if command -v zenity >/dev/null 2>&1; then zenity --error --title="Unora Overlay" --text="$msg"
    elif command -v notify-send >/dev/null 2>&1; then notify-send "Unora Overlay" "$msg"
    fi
    echo "$msg" >&2
    exit 1
fi

exec python3 "$DIR/unora_overlay.py" "$@"
