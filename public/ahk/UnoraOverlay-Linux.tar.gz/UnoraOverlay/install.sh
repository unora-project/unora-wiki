#!/bin/sh
# Unora Overlay - one-time set-up for Linux.
#   1. Installs the system packages it needs (asks for your password).
#   2. Adds "Unora Overlay" to your applications menu.
# Run it from a terminal:  ./install.sh      (add --no-packages to skip step 1)
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$1" != "--no-packages" ]; then
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get install -y python3 python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 \
            gir1.2-ayatanaappindicator3-0.1 python3-xlib libnotify-bin
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y python3 python3-gobject gtk3 webkit2gtk4.1 \
            libayatana-appindicator-gtk3 python3-xlib libnotify
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -S --needed --noconfirm python python-gobject gtk3 webkit2gtk-4.1 \
            libayatana-appindicator python-xlib libnotify
    elif command -v zypper >/dev/null 2>&1; then
        sudo zypper install -y python3 python3-gobject python3-gobject-Gdk typelib-1_0-Gtk-3_0 \
            typelib-1_0-WebKit2-4_1 typelib-1_0-AyatanaAppIndicator3-0_1 python3-python-xlib libnotify-tools
    else
        echo "Could not find apt, dnf, pacman or zypper."
        echo "Install these yourself: Python 3, PyGObject, GTK 3, WebKitGTK (WebKit2 4.1),"
        echo "Ayatana AppIndicator (optional), python-xlib, notify-send (optional)."
    fi
fi

chmod +x "$DIR/UnoraOverlay.sh" "$DIR/unora_overlay.py"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$APPS"
ESC=$(printf '%s' "$DIR/UnoraOverlay.sh" | sed 's/[\\"`$]/\\&/g')
cat > "$APPS/unora-overlay.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Unora Overlay
Comment=The Unora Wiki on top of your game
Exec="$ESC"
Icon=$DIR/UnoraOverlay.png
Terminal=false
Categories=Game;Utility;
StartupWMClass=unora-overlay
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" 2>/dev/null || true

echo
echo "Done. Start \"Unora Overlay\" from your applications menu, or run:"
echo "  \"$DIR/UnoraOverlay.sh\""
