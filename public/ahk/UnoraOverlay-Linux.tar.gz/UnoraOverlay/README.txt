UNORA OVERLAY FOR LINUX  -  the Unora Wiki, right on top of your game
======================================================================

Unora Overlay opens the Unora Wiki (unora.wiki) in a small window that sits
over the game, so you can check a quest guide, look up an item, compare gear
or plan your skills without alt-tabbing to a browser.

It shows the real website, so it is always up to date with the wiki.
This is the native Linux version of the Windows overlay (version 1.8.0). It does
the same things, built on GTK and WebKitGTK instead of AutoHotkey and WebView2.


WHAT YOU NEED
-------------
1. A Linux desktop running an X11 session (Linux Mint Cinnamon, Xfce, MATE, KDE or
   GNOME "on Xorg"...). See WAYLAND below if your desktop uses Wayland.
2. A few system packages: Python 3, GTK 3, WebKitGTK, python-xlib, and (for the
   tray icon) Ayatana AppIndicator. install.sh installs them for you.
   On Linux Mint / Ubuntu / Debian they are:
      python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 gir1.2-ayatanaappindicator3-0.1
      python3-xlib libnotify-bin


INSTALL
-------
1. Unpack the whole UnoraOverlay folder somewhere in your home folder, such as
   ~/Games or ~/Documents.
2. Keep everything together. The folder must contain:
      UnoraOverlay.sh     (start this one)
      unora_overlay.py    (the overlay itself)
      UnoraOverlay.png    (the icon)
      install.sh          (one-time set-up)
      README.txt
3. Open a terminal in the folder and run:
      ./install.sh
   It installs the packages above (it asks for your password) and adds
   "Unora Overlay" to your applications menu. If you have already installed the
   packages, run  ./install.sh --no-packages  to only add the menu entry.
4. Start "Unora Overlay" from the applications menu, or double-click
   UnoraOverlay.sh (choose "Run" if your file manager asks). The first time, the
   menu opens by itself.

The overlay lives in your system tray (the panel, near the clock). Click its icon
for the menu, Options, and Exit.


PLAYING WITH THE GAME
---------------------
* Run the game (through Wine, Lutris, Bottles, Steam/Proton...) in Windowed or
  Borderless-windowed mode. A true "exclusive fullscreen" game will hide the overlay.
* The wiki window can be moved and resized like any window. Press Pin to keep
  it on top of the game (or unpin it).


KEYBINDS (the defaults)
-----------------------
  Ctrl+Alt+U    Open the menu
  Ctrl+Alt+W    Show / hide the wiki window
  Ctrl+Alt+B    Open the Build Planner
  Ctrl+Alt+H    Open the HP/MP Calculator
  Ctrl+Alt+S    Open the Stat Calculator
  Ctrl+Alt+O    Open Options
  Ctrl+Alt+Middle click    Add the skill/spell under the mouse to your Build Planner (see below)

Change any of them in Options (see below). The keybinds work everywhere, also while
the game has focus. If a key is already used by your desktop (some desktops use
Ctrl+Alt+arrows, Ctrl+Alt+T, Ctrl+Alt+Delete...), the overlay tells you and you can
pick another one.


THE MENU
--------
Press the Menu key. The menu has two parts.

Unora Wiki (opens the wiki window):
  Classes        Skills and spells for every class. On a class page, use the
                 "Build Plan" button to plan what to learn, just like the website.
  Items          All equipment. Use "Compare Equipment" to compare items,
                 and pick an enchant to see how it changes the stats.
  Quests         Quest guides.
  Professions    Recipes and tables for each profession.

Tools (each opens its own small window):
  Build Planner      Just your build plan.
  HP/MP Calculator   Experience costs for raising HP and MP.
  Stat Calculator    Experience needed to max your stats.

The ? button explains the page or window you are looking at. It is at the top right of the
menu, the wiki window, and the Build Planner, HP/MP Calculator and Stat Calculator windows.

The wiki window has a bar along the top:
  Back / Forward / Reload   work like a browser
  Menu       opens the menu again
  Planner    opens the Build Planner window
  Pin        keeps the window on top of the game
  Options    opens Options
  ?          help for the page you are looking at
Closing the wiki window with its X only hides it. Your page is still there when
you open it again. To quit completely, use the tray icon > Exit.


THE BUILD PLANNER AND "REMEMBERING"
-----------------------------------
The Build Planner button (Ctrl+Alt+B) opens a small, separate window with just your plan.
Press the key again to hide it. It stays on top of the game (the Pin setting) and remembers where you put it.
Click the ? at the top right of the window for a short guide, including the in-game add key.
  - The drop-down at the top switches class. "Your plans" are classes with picks; "Start a plan for..."
    lists the rest.
  - Type a skill or spell name in the box and press Enter (or click a result) to add it.
  - The plan shows where to learn each one, the gold, the highest STR/INT/WIS/CON/DEX needed
    for everything selected, and the materials, which you can tick off. X removes a skill.
  - Picks are shared with the main wiki window, so changes in either show up in both.


Your Build Plan picks, hidden skills, ticked-off materials and other website
settings are remembered between sessions. The overlay keeps its own browser
storage in the "data" folder next to the script.
IMPORTANT: this is separate from your normal web browser (and from the Windows
overlay). Picks made on unora.wiki in Firefox/Chrome do not appear in the overlay,
and the other way round.
Do not delete the "data" folder unless you want to forget your picks.


THE HP/MP CALCULATOR
--------------------
Menu > HP/MP Calculator (or Ctrl+Alt+H) opens a small window with just the calculator.
Press the key again to hide it. It stays on top of the game and remembers where you put it.
HP goes up in steps of 50 and MP in steps of 25. Each raise costs 500 experience for every
point of your base before the raise (for example HP 58,074 to 58,124 costs 29,037,000).
  Between Two Bases   Type a starting and an ending base for HP, MP or both and press Calculate
                      to see the total experience.
  Max Raise from Exp  Choose HP or MP, type your current base and the experience you have, and
                      it shows the base you can reach and what is left over.
Click the ? at the top right of the window for a short guide.


THE STAT CALCULATOR
-------------------
Menu > Stat Calculator (or Ctrl+Alt+S) opens a small window with just the stat calculator.
Press the key again to hide it. It stays on top of the game and remembers where you put it.
  1. Pick your Class and Progression (Pre-Master, Master or Grandmaster). The maximum for each
     stat is filled in.
  2. Type your current STR, INT, WIS, CON and DEX.
  3. Optional: XP/hour (in millions) gives an estimated time, and Current Experience is taken
     off the total.
The result lists the experience needed for each stat and the total.
Click the ? at the top right of the window for a short guide.


OPTIONS
-------
Open it with the Options key, the Options button, or the tray menu.

  Keybinds     Click a box and press the keys you want. Backspace clears one.
               Each action needs its own key. Reset keys restores the defaults.
               While a box is selected the overlay's own keys are switched off, so
               you can record them.
               "Add skill/spell from game (mouse)" is a mouse click, so it has a list instead
               of a key box (see ADD A SKILL FROM THE GAME below).
  Appearance   Colour theme: Unora (the website's colours - the default), Dark,
               Light, Midnight (dark blues), Crimson (dark reds), Forest (dark greens).
               Fade when not in use: the wiki, Build Planner, HP/MP Calculator and Stat Calculator windows fade to this level
               when your mouse is away from them and you are not using them, so the game
               shows through. They turn fully solid again as soon as you point at them or
               click them, so they stay easy to read. 100 turns fading off.
               Fading needs a desktop with compositing (Cinnamon, KDE, GNOME and most others
               have it on). If a window ever looks blank or black, set this to 100.
               Page size (zoom): make the website smaller or bigger inside the window.
  Window       Keep the wiki window on top of the game.
  Game         Start automatically when the game launcher opens (see below).
  Updates      Check for a new version when the overlay starts.

Your choices are saved in two small text files next to the script:
  settings.cfg   theme, window size/position, opacity, zoom, update options
  keybinds.cfg   your keys
You can open them in any text editor. Deleting one resets that part to the defaults.
They use the same format as the Windows overlay, so you can copy them across.
These files are never touched by updates.


ADD A SKILL FROM THE GAME
-------------------------
Point the mouse at a skill or spell in the game (its name or icon on the Skill/Spell page,
or its detail pop-up) and press Ctrl+Alt+Middle click. The overlay takes a small picture of
the screen around the mouse, the Build Planner reads the game's own text from it, finds the
matching skill or spell, and adds it to your plan. A short message near the top of the screen
tells you what was added (or why not). If it is not found in your current class it also
looks through the other classes.
  - It reads only the skill's NAME text, never the icon, so two skills that share a picture are
    never mixed up. If the text could be two similar names, it tells you it is not sure instead of
    guessing; point at the name again or type it in the box.
  - The game must be windowed or borderless. Any window size works, from the game's own 640x480 up
    (1280x960, 1920x1080, a window you dragged to some odd size...). The overlay measures the game
    picture itself. Sizes that are a whole multiple of 640x480 (1280x960, 1920x1440) read most
    reliably. A window smaller than 640x480 is too small to read.
  - Change the click in Options > Keybinds ("Add skill/spell from game (mouse)"). The list has
    Ctrl+Alt, Ctrl+Shift, Alt, Ctrl or Shift + Middle click, the side mouse buttons (Mouse 4 and
    Mouse 5, alone or with Ctrl+Alt or Alt), or Off. Save to apply it.
  - Not reading well? The last picture it looked at is saved in the "data" folder as
    ocr-last.png. You can always type the name into the Build Planner box instead.


START WITH THE GAME LAUNCHER
----------------------------
Tick "Start automatically when the game launcher opens" in Options > Game and Save.
This adds a start-up entry (~/.config/autostart/unora-overlay.desktop). From then on the
overlay starts when you log in and waits quietly in the tray (no window, no keybinds). As
soon as the launcher window ("Chaos Launcher") is open, it switches on, shows a small "ready"
notice, and your keybinds work. Untick the box and Save to turn it off again (this removes the
start-up entry). To exit the overlay, use the tray icon > Exit.
The launcher is found by its window title (upper or lower case does not matter). If the title
is different, or you want other windows to count too, edit GameWindow in settings.cfg (part of
the title is enough, separate several with commas):  GameWindow=Chaos Launcher,Unora
You can also list program names in GameProcess (for example GameProcess=Unora.exe); Wine
programs count too.
If you move the UnoraOverlay folder, open the overlay once and press Save in Options
so the start-up entry points to the new place (and run ./install.sh --no-packages again to
update the applications menu entry).


UPDATES
-------
When the overlay starts it quietly checks unora.wiki for a newer Linux version. If there
is one, a window tells you what changed and offers:
  Update now          downloads the new unora_overlay.py, checks it, keeps a backup copy
                      (unora_overlay.py.bak), and restarts the overlay.
  Later               ask again next time.
  Skip this version   stop asking about this version.
Your settings.cfg, keybinds.cfg and saved picks are kept. You can also check any
time from Options > Check now, or the tray menu > Check for updates.
Updates only replace unora_overlay.py. If a release ever needs new system packages, the
update window will say so.


WAYLAND
-------
The overlay runs through XWayland on a Wayland desktop (UnoraOverlay.sh sets this up).
The windows, the website and the tray icon work, but Wayland does not let programs use
keys everywhere or read the screen, so the keybinds and "Add a skill from the game" only
work while an XWayland window (for example a Wine game) is focused, and some desktops
block them completely. For the full overlay, pick an X11 session at the log-in screen
(on Linux Mint, "Cinnamon" rather than "Cinnamon on Wayland"; on Ubuntu, "Ubuntu on Xorg").
"Keep on top" can also be ignored on some Wayland desktops.


TROUBLESHOOTING
---------------
Nothing happens when I start UnoraOverlay.sh / "needs a few system packages":
    Run ./install.sh in a terminal in the UnoraOverlay folder. To see error messages,
    start the overlay from a terminal:  ./UnoraOverlay.sh
Double-clicking UnoraOverlay.sh opens it in a text editor:
    Right-click it > Properties > Permissions and allow running it as a program, or
    start "Unora Overlay" from the applications menu after running install.sh.
There is no tray icon:
    Install the Ayatana AppIndicator package (install.sh does this). On GNOME, also
    turn on the "AppIndicator and KStatusNotifierItem Support" extension. Without a tray,
    the keybinds still work; Ctrl+Alt+U opens the menu.
Keybinds do nothing:
    Check you are in an X11 session (see WAYLAND). Check the key is not already used by
    your desktop, the game or another program, and try another in Options.
The window does not show over the game:
    Switch the game to Windowed or Borderless mode, and make sure Pin is on.
The window is blank or black:
    Set "Fade when not in use" to 100 in Options. Press Reload in the top bar.
    (UnoraOverlay.sh already turns off a WebKit feature that causes blank pages with some
    graphics drivers.)
Some other problem with a page:
    Press Reload. If a page is wrong on the website too, tell the wiki team.
"Could not save your settings":
    The folder is read-only. Move the UnoraOverlay folder into your home folder.

To uninstall: tray icon > Exit, untick "Start automatically" first if you used it (or delete
~/.config/autostart/unora-overlay.desktop), delete
~/.local/share/applications/unora-overlay.desktop, then delete the folder.


CREDITS AND LICENCES
--------------------
Unora Wiki is an unofficial fan compendium for Unora: Elemental Harmony.
The Linux version uses GTK, WebKitGTK and python-xlib from your Linux distribution.
It contains no AutoHotkey or Microsoft files.
